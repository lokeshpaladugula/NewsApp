package com.dexterous.flutterlocalnotifications;

import androidx.annotation.Keep;

@Keep
public enum BitmapSource {
    DrawableResource,
    FilePath
}
