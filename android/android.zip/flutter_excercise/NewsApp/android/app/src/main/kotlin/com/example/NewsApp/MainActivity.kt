package com.example.NewsApp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
